# frozen_string_literal: false
#
#   tkmenubar.rb - load tk/menubar.rb
#
require 'tk/menubar'
