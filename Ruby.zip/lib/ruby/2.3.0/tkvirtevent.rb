# frozen_string_literal: false
#
#   tkvirtevent.rb - load tk/virtevent.rb
#
require 'tk/virtevent'
