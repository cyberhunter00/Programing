# frozen_string_literal: false
#
#   tkscrollbox.rb - load tk/scrollbox.rb
#
require 'tk/scrollbox'
