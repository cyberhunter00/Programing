# frozen_string_literal: false
#
#   tkconsole.rb - load tk/console.rb
#
require 'tk/console'
