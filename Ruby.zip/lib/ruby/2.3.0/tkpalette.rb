# frozen_string_literal: false
#
#   tkpalette.rb - load tk/palette.rb
#
require 'tk/palette'
