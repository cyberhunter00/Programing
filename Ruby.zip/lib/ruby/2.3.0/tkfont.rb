# frozen_string_literal: false
#
#   tkfont.rb - load tk/font.rb
#
require 'tk/font'
